?package(tuxconfig):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="tuxconfig" command="/usr/bin/tuxconfig"
