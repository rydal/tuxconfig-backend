#
# Regular cron jobs for the tuxconfig package
#
0 4	* * *	root	[ -x /usr/bin/tuxconfig_maintenance ] && /usr/bin/tuxconfig_maintenance
